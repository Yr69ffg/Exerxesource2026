# ExtrexSource 2026 — v0.0.1

A standalone car-game engine/editor foundation targeting Windows 10/11. The baseline visual target is PS2/early-2000s, with configurable quality rather than a fixed low-quality renderer.

## v0.0.1 currently includes
- C++17 engine/editor executable
- 3D viewport and scene grid
- Scene hierarchy and inspector
- Vehicle entity foundation
- Camera and UI entity foundations
- Project serialization (`.exproj`) and map serialization (`.exmap`)
- Play/Test mode (F5)
- Save (Ctrl+S)
- Export/build-package action (F6)
- Assets/Maps/Materials/Vehicles project structure
- Initial AI-command hook
- Windows CI workflow that builds with MSVC on GitHub Actions
- Inno Setup installer script
- ZIP packaging through CPack

## Roadmap modules
Vehicle physics, suspension/drivetrain/gearbox/tires, GLTF/OBJ/FBX import, audio, materials, UI editor, multiplayer, visual scripting, AI assistant, and full Windows runtime/export pipeline are being expanded on top of this foundation.

## Build
Use CMake 3.20+ and a C++17 compiler. The GitHub Actions workflow builds a Windows package automatically.
