#define MyAppName "ExtrexSource 2026"
#define MyAppVersion "0.0.1"
#define MyAppPublisher "Extrex"
#define MyAppExeName "ExtrexSourceEditor.exe"
[Setup]
AppId={{E3B2D5F7-2026-EXTREX-0001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ExtrexSource2026
DefaultGroupName=ExtrexSource 2026
OutputDir=Output
OutputBaseFilename=ExtrexSource2026-v0.0.1-Setup
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
[Files]
Source: "..\package\bin\ExtrexSourceEditor.exe"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{autodesktop}\ExtrexSource 2026"; Filename: "{app}\ExtrexSourceEditor.exe"
Name: "{group}\ExtrexSource 2026"; Filename: "{app}\ExtrexSourceEditor.exe"
